// =========================================================================
// Practical 4: StarCore-1 — Single-Cycle Processor in Verilog
// =========================================================================
//
// GROUP NUMBER: 9
//
// MEMBERS:
//   - Joshua Smith, SMTJOS022
//   - Ebrahim Bhyat, BHYEBR002

`include "Parameter.v"
`include "ALU.v"
`include "GPR.v"
`include "InstructionMemory.v"
`include "DataMemory.v"
`include "ALU_Control.v"

module Datapath(

    input clk,
    input reset,

    // inputs from the control unit
    input RegDst, 
    input ALUSrc,
    input MemToReg,
    input RegWrite,
    input MemRd,
    input MemWr,
    input Branch,
    input [1:0] ALUOp,
    input Jump,

    output [3:0] opcode 

);

    // --- Internal Wires ---
    reg  [`WORDWIDTH-1:0] pc;
    wire [`WORDWIDTH-1:0] next_pc;
    wire [`WORDWIDTH-1:0] current_instruction;
    
    // GPR Wires
    wire [2:0]            write_reg_addr;
    wire [`WORDWIDTH-1:0] write_data;
    wire [`WORDWIDTH-1:0] read_data1;
    wire [`WORDWIDTH-1:0] read_data2;

    // ALU Wires
    wire [2:0]            alu_control_code;
    wire [`WORDWIDTH-1:0] alu_input_b;
    wire [`WORDWIDTH-1:0] alu_result;
    wire alu_zero;
    
    // Data Memory Wires
    wire [`WORDWIDTH-1:0] memory_read_data;

    assign opcode = current_instruction[15:12];

    // ---------------------------------------------------------
    // INSTRUCTION MEMORY
    // ---------------------------------------------------------
    InstructionMemory inst_mem (
        .pc(pc), 
        .instruction(current_instruction)
    );

    // ---------------------------------------------------------
    // MULTIPLEXER: RegDst
    // R-Type uses bits [5:3] and I-Type uses bits [8:6]
    assign write_reg_addr = (RegDst == 1'b1) ? current_instruction[5:3] : current_instruction[8:6];

    // ---------------------------------------------------------
    // GENERAL PURPOSE REGISTERS (GPR)
    // ---------------------------------------------------------
    GPR register_file (
        .clk(clk),
        .write_en(RegWrite),                 
        .read_addr1(current_instruction[11:9]), 
        .read_addr2(current_instruction[8:6]),  
        .write_addr(write_reg_addr),         
        .write_data(write_data),             
        .read_data1(read_data1),
        .read_data2(read_data2)
    );

    // ---------------------------------------------------------
    // ALU CONTROL UNIT
    // ---------------------------------------------------------
    ALU_Control alu_ctrl (
        .ALUOp(ALUOp),                       // From Control Unit IN port
        .opcode(current_instruction[15:12]),
        .ALUcnt(alu_control_code)
    );

    // ---------------------------------------------------------
    // MULTIPLEXER: ALUSrc (Choose between Reg2 or Immediate)
    // ---------------------------------------------------------
    // Note: You will need to sign-extend the immediate value. 
    // Sign-extend the 6-bit offset [5:0] to 16 bits
    wire [`WORDWIDTH-1:0] sign_extended_imm = {{10{current_instruction[5]}}, current_instruction[5:0]};
    
    assign alu_input_b = (ALUSrc == 1'b1) ? sign_extended_imm : read_data2;

    // THE ALU
    ALU main_alu (
        .a(read_data1),
        .b(alu_input_b),          // From the ALUSrc MUX
        .ALUcnt(alu_control_code),// From the ALU_Control
        .result(alu_result),
        .zero(alu_zero)
    );

    // DATA MEMORY
    DataMemory data_mem (
        .clk(clk),
        .MemRd(MemRd),
        .MemWr(MemWr),
        .addr(alu_result[2:0]),   // Usually, the ALU calculates the memory address
        .write_data(read_data2),  // The data we want to store comes from Register 2
        .read_data(memory_read_data)
    );

    // MULTIPLEXER: MemToReg (Write back to GPR)
    assign write_data = (MemToReg == 1'b1) ? memory_read_data : alu_result;


    // --- PC Calculation Logic ---
    wire [`WORDWIDTH-1:0] pc_plus_2 = pc + 2;
    
    // Branch Target: Shift the sign-extended immediate left by 1, then add to PC+2
    wire [`WORDWIDTH-1:0] branch_offset = sign_extended_imm << 1;
    wire [`WORDWIDTH-1:0] branch_target = pc_plus_2 + branch_offset;
    
    // Jump Target: Upper 3 bits of PC, 12-bit offset, and a 0 at the end
    wire [`WORDWIDTH-1:0] jump_target = {pc[15:13], current_instruction[11:0], 1'b0};

    // Determine if we actually take the branch based on BEQ/BNE rules
    wire is_beq = (opcode == 4'b1011);
    wire is_bne = (opcode == 4'b1100);
    wire take_branch = Branch & ((is_beq & alu_zero) | (is_bne & ~alu_zero));

    // The sequential PC Update
    always @(posedge clk) begin
        if (reset) begin
            pc <= `WORDWIDTH'd0; 
        end else if (Jump) begin
            pc <= jump_target;      // Execute JMP
        end else if (take_branch) begin
            pc <= branch_target;    // Execute BEQ or BNE
        end else begin
            pc <= pc_plus_2;        // Standard execution
        end
    end

endmodule
    