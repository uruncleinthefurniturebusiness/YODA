// =========================================================================
// Practical 4: StarCore-1 — Single-Cycle Processor in Verilog
// =========================================================================
//
// GROUP NUMBER: 9
//
// MEMBERS:
//   - Joshua Smith, SMTJOS022
//   - Ebrahim Bhyat, BHYEBR002

`timescale 1ns / 1ps

`define WORDWIDTH 16
`define INSTRUCTION_DEPTH 16
`define DATA_DEPTH 8
`define SIM_TIME 1
